interface VisitorOperacao {
    void visitAdicao(Adicao adicao);
    void visitMultiplicacao(Multiplicacao multiplicacao);
}
