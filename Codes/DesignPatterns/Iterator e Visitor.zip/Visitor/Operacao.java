interface Operacao {
    void aceita(VisitorOperacao visitorOp);
}
