interface Figura {
    public float area();
    public void print();
}